"""
__init__.py - SLA-P1-Logic 标签逻辑中心注册文件
功能：
1. 注册 V1.5.5 重构版 P1 Labeler。
2. 协议升级：将输出从 LIST 转为 CONDITIONING，开启 ZZ 协议支持。
3. 自动同步物理压强（Strength）至下游 P3/P4。
"""
import os
import sys

# 1. 路径锚定
NODE_DIR = os.path.dirname(os.path.realpath(__file__))
if NODE_DIR not in sys.path:
    sys.path.append(NODE_DIR)

# 2. 导入重构后的 P1 类
try:
    from .OmniSLAMainNode import OmniSLA_P1_Labeler_V1_5
    
    # 建立映射
    # 🛠️ 这里的 Key "OmniSLA_P1_Labeler_V1" 必须保持不变，以兼容你现有的 Workflow
    NODE_CLASS_MAPPINGS = {
        "OmniSLA_P1_Labeler_V1": OmniSLA_P1_Labeler_V1_5
    }
    
    # 前端显示名称升级
    NODE_DISPLAY_NAME_MAPPINGS = {
        "OmniSLA_P1_Labeler_V1": "🧬 SLA P1: Logical Labeler (Zenith-ZZ)"
    }
    
    print("✅ [SLA-System] P1 标签逻辑中心 (Zenith-ZZ) 注册成功")

except Exception as e:
    print(f"🚨 [SLA-System] P1 注册失败: {e}")

# 3. 导出映射
__all__ = ['NODE_CLASS_MAPPINGS', 'NODE_DISPLAY_NAME_MAPPINGS']