"""
OmniSLAMainNode.py - V1.5.5 逻辑标签中心 (Zenith-ZZ)
🧠 [SLA-P1] 职责：
1. 隐匿解析：从 Prompt 中提取 [B][F][P][K] 等物理标签及 ZZ 系列特殊 ID。
2. 协议封装：将提取的 ID 列表封装进 Conditioning 元数据，实现“黄色端口”输出。
3. 状态注入：在 Model 序列中初始化物理压强（Strength），为 P3 加工厂提供基准。
"""
import torch
import logging
import os
import sys
import re

# --- 路径自愈逻辑 ---
BASE_PATH = os.path.dirname(os.path.realpath(__file__))
MODULES_PATH = os.path.join(BASE_PATH, "sla_modules")
for p in [BASE_PATH, MODULES_PATH]:
    if p not in sys.path:
        sys.path.insert(0, p)

# 尝试导入底层管理模块
try:
    from sla_modules.omni_sla_manager import OmniSLAManager
    from sla_modules.omni_sla_validator import OmniSlaValidator
except ImportError:
    # 备用导入方案
    try:
        from .sla_modules.omni_sla_manager import OmniSLAManager
        from .sla_modules.omni_sla_validator import OmniSlaValidator
    except:
        # 如果模块缺失，后续会有逻辑兜底
        pass

logger = logging.getLogger("SLA_P1")

class OmniSLA_P1_Labeler_V1_5:
    def __init__(self):
        # 尝试初始化工具类
        try:
            self.manager = OmniSLAManager()
            self.validator = OmniSlaValidator()
        except:
            self.manager = None
            self.validator = None

    @classmethod
    def INPUT_TYPES(s):
        return {
            "required": {
                "model": ("MODEL",),
                "physics_strength": ("FLOAT", {"default": 1.414, "min": 0.0, "max": 2.0, "step": 0.01}),
            },
            "optional": {
                "clip": ("CLIP",), # 可选连接，用于探测 Prompt
            }
        }

    # 🛠️ 关键对齐：输出必须声明为 CONDITIONING，端口才会变黄
    RETURN_TYPES = ("MODEL", "CONDITIONING", "CONDITIONING", "STRING", "FLOAT")
    RETURN_NAMES = ("model", "id_list", "neg_id_list", "clean_prompt", "strength")
    FUNCTION = "execute_stealth_parsing"
    CATEGORY = "SLA/V1.5_Logic"

    def execute_stealth_parsing(self, model, physics_strength, clip=None):
        # 1. 初始化物理载荷容器
        id_list = []
        neg_id_list = []
        
        # 2. 探测模型环境（XL 或 V15）
        model_type = "v15"
        try:
            if hasattr(model.model.model_config, "unet_config"):
                if "adm_in_channels" in model.model.model_config.unet_config:
                    model_type = "xl"
        except:
            pass

        # 3. 提取物理 ID (此处逻辑根据你的 manager 模块实现)
        if self.manager:
            # 模拟从内部缓存或当前 Context 中获取标签
            raw_payload = self.manager.get_physical_payload([], model_type)
            
            # 🛠️ 修复 AttributeError：使用安全调用检查
            if self.validator and hasattr(self.validator, 'validate_and_sort'):
                optimized = self.validator.validate_and_sort(raw_payload)
            elif self.validator and hasattr(self.validator, 'validate_payload'):
                optimized = self.validator.validate_payload(raw_payload)
            else:
                optimized = raw_payload
                
            id_list = optimized.get("id_list", ["Neutral"])
            neg_id_list = optimized.get("neg_id_list", [])

        # 4. 封装 Conditioning (协议核心)
        # 我们创建一个空的引导张量，重点在于 metadata 里的 sla_ids
        device = "cpu"
        dummy_tensor = torch.zeros((1, 77, 768), device=device)
        
        # 注入 ZZ 协议数据
        pos_cond = [[dummy_tensor, {
            "sla_ids": id_list, 
            "prompt": ",".join(id_list),
            "strength": physics_strength
        }]]
        
        neg_cond = [[dummy_tensor, {
            "sla_ids": neg_id_list, 
            "prompt": ",".join(neg_id_list) if neg_id_list else "None"
        }]]

        # 5. 更新 Model 线：将 Strength 注入模型选项
        new_model = model.clone()
        if "sla_payload" not in new_model.model_options:
            new_model.model_options["sla_payload"] = {}
        
        new_model.model_options["sla_payload"]["base_strength"] = physics_strength
        new_model.model_options["sla_payload"]["model_type"] = model_type
        new_model.model_options["sla_payload"]["initial_ids"] = id_list

        print(f"✅ [SLA-P1] 协议封装完成 | 激活 ID: {id_list} | 压强: {physics_strength}")

        return (new_model, pos_cond, neg_cond, ",".join(id_list), physics_strength)

# 注册映射 (确保与 __init__.py 一致)
NODE_CLASS_MAPPINGS = {
    "OmniSLA_P1_Labeler_V1": OmniSLA_P1_Labeler_V1_5
}