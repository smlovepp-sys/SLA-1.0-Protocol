import json
import os
import logging
import re

logger = logging.getLogger("SLA_P1")

class DanbooruTagProcessor:
    def __init__(self):
        # 1. 定义物理属性探测器（基于你 JSON 中的 tag 字段）
        self.phys_heuristics = {
            'F': r"dress|cloth|skirt|shirt|fabric|apron|suit|bra|pant",
            'E': r"hair|fringe|bangs|fluid|water|fire|smoke|magic",
            'B': r"body|muscle|skin|thigh|breast|belly|hand|arm|leg",
            'R': r"bone|skeleton|joint|structure"
        }
        
        self.module_path = os.path.dirname(os.path.realpath(__file__))
        self.base_path = os.path.dirname(self.module_path)
        
        # 载入数据
        self.v15_map = self._load_map("p1_map_v15.json")
        self.xl_map = self._load_map("p1_map_xl.json")

    def _load_map(self, file_name):
        json_path = os.path.join(self.base_path, file_name)
        cleaned_data = {}
        try:
            if os.path.exists(json_path):
                with open(json_path, 'r', encoding='utf-8') as f:
                    raw_data = json.load(f)
                    for token_id, info in raw_data.items():
                        if isinstance(info, dict):
                            tag_str = info.get("tag", "").lower()
                            raw_id = info.get("id", "ZZ")
                            
                            # --- 核心逻辑：打破 ZZ 封锁 ---
                            # 如果 ID 是 ZZ，我们通过 tag 字符串强制“染色”
                            assigned_phys = "Z"
                            for phys_code, pattern in self.phys_heuristics.items():
                                if re.search(pattern, tag_str):
                                    assigned_phys = phys_code
                                    break
                            
                            # 如果 tag 没匹配到，但 ID 本身有 R/B/F/E 开头，则保留
                            if assigned_phys == "Z" and raw_id[0] in ["R", "B", "F", "E"]:
                                assigned_phys = raw_id[0]
                                
                            cleaned_data[str(token_id)] = assigned_phys
                    
                    logger.info(f"✅ [SLA-P1] 物理映射激活成功: {file_name}")
                    return cleaned_data
            return {}
        except Exception as e:
            logger.error(f"🚨 [SLA-P1] 加载异常: {e}")
            return {}

    def get_id_type(self, token_id, model_type="v15"):
        target_map = self.xl_map if model_type == "xl" else self.v15_map
        return target_map.get(str(token_id), "Z")