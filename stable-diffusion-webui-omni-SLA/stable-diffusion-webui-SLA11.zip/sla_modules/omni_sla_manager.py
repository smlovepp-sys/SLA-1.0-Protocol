"""
omni_sla_manager.py - V1.2.0 Zenith-Executive (Restructured)
功能：物理 ID 翻译与事实分发中心。
职责：
1. 接收来自 OmniSLAMainNode 的 Token ID 流。
2. 调度 Processor 完成从 Token 到 物理 ID (如 ZZ1811N) 的翻译。
3. 保证 ID 的去重与物理指纹的完整性。
"""
import os
import re
import logging
from typing import List, Dict, Any

# 路径自愈，确保能找到你修改后的处理器
try:
    from .danbooru_tag_processor import DanbooruTagProcessor
except ImportError:
    from danbooru_tag_processor import DanbooruTagProcessor

logger = logging.getLogger("SLA_P1")

class OmniSLAManager:
    def __init__(self):
        # 挂载你修改过的具备 ZZ ID 解析能力的处理器
        self.processor = DanbooruTagProcessor()
        self._reset_state()

    def _reset_state(self):
        """状态重置，防止跨批次（Batch）数据污染"""
        self.current_found_ids = []

    def get_physical_payload(self, input_data: Any, model_type: str = "v15") -> Dict[str, Any]:
        """
        核心调度方法：
        1. 接收 Token 列表
        2. 转换为物理 ID 列表 (R/B/F/E/ZZ...)
        3. 封装为 Payload
        """
        self._reset_state()
        seen_physical_ids = [] # 使用列表保持原始 Prompt 顺序，这对物理场优先级很重要

        # --- 1. 数据清洗与标准化 ---
        if isinstance(input_data, list):
            # 模式 A：Token ID 流模式 (推荐)
            search_list = [str(x) for x in input_data]
        else:
            # 模式 B：文本正则模式 (用于直接输入文本的场景)
            search_list = re.findall(r'\[(.*?)\\]', str(input_data))
            if not search_list:
                # 尝试对整个字符串进行分词处理（兜底）
                search_list = str(input_data).split(',')

        # --- 2. 核心翻译阶段 (调用你的 Processor) ---
        for item in search_list:
            item = item.strip()
            if not item:
                continue
                
            # 向处理器请求 ID。注意：这里会触发你修改后的 ZZ 识别逻辑
            phys_id = self.processor.get_id_type(item, model_type=model_type)
            
            # 如果不是 Z (Neutral)，则认为是一个有效的物理实体
            if phys_id != "Z" and phys_id not in seen_physical_ids:
                seen_physical_ids.append(phys_id)

        # --- 3. 封装载荷 ---
        # 这里的结构必须对应 Validator 和 Injector 的预期
        payload = {
            "id_list": seen_physical_ids,
            "entity_count": len(seen_physical_ids),
            "model_type": model_type,
            "vram_status": "NORMAL" # 初始状态，由后续 Validator 修改
        }

        if len(seen_physical_ids) > 0:
            logger.info(f"🧬 [SLA-Manager] 成功提取物理实体: {', '.join(seen_physical_ids)}")
        
        return payload